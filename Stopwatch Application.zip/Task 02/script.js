let startTime, updatedTime, difference, timerInterval;
let isRunning=false;
let lapcount=1;

const display=document.getElementById("display");
const startBtn=document.getElementById("start");
const pauseBtn=document.getElementById("pause");
const resetBtn=document.getElementById("reset");
const lapBtn=document.getElementById("lap");
const laps=document.getElementById("laps");

startBtn.addEventListener("click", () => {
    if(!isRunning) {
        isRunning=true;
        startTime=new Date().getTime() - (difference || 0);
        timerInterval=setInterval(updatedTime, 1000);
    }
});

pauseBtn.addEventListener("click", () => {
    if(isRunning) {
        isRunning=false;
        clearInterval(timerInterval);
    }
});

resetBtn.addEventListener("click", () => {
    isRunning=false;
    clearInterval(timerInterval);
    difference=0;
    display.textContent="00:00:00";
    laps.innerHTML="";
    lapcount=1;
});

lapBtn.addEventListener("click", () => {
    if(isRunning) {
        const li=document.createElement("li");
        li.textContent= `Lap ${lapcount++}: ${display.textContent}`;
        laps.appendChild(li);
    }
});

function updateTime() {
    updatedTime=new Date().getTime();
    difference=updatedTime - startTime;

    let hours=Math.floor(difference / (1000*60*60));
    let minutes=Math.floor((difference % (1000*60*60)) / (1000*60));    
    let seconds=Math.floor((difference % (1000*60)) / 1000);

    display.textContent=`${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function pad(unit) {
    return unit < 10 ? "0" + unit : unit;
}
